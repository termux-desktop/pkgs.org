# Termux-DialerGUI
It's a Dialer for termux desktop

## dependencies
termux-api

python.tkinter


### preview
<img width="400" alt="imagen" src="https://user-images.githubusercontent.com/25087943/112321165-19b91b80-8c86-11eb-8891-2510b5112ea5.png">
