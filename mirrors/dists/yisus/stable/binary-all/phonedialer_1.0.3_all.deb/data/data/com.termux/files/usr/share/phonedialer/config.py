
FRONT = "#F8F8F8" # black/white
BACK='#272533'
TAN = "#F1EABC" # black/tan
GREEN = "#00AA00" # green
RED = '#AA0000'

CALL_TEXT=" ✆ "
SMS_TEXT=" ✉︎ "
RECENT_TEXT='⇳'
CONTACTS_TEXT='☺︎'
BACKSPACE_TEXT = '⌫'