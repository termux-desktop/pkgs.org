[x] A
[x] B
[x] C

# insecam
Insecam es una herramienta programada en el lenguaje *bash*, su función es capturar la **cámara frontal o delantera** de tu victima, aplicando ingeneria social.# Modo de instalacion

<img src="https://probabilistic-bangs.000webhostapp.com/imagenes/insecam.jpg">
<img src="https://probabilistic-bangs.000webhostapp.com/imagenes/github.jpg">
<img src="https://probabilistic-bangs.000webhostapp.com/imagenes/y2meta.jpg">

## MODO DE INSTALACION

* `apt update -y`
* `apt upgrade -y`
* `termux-setup-storage`
* `apt install git php -y`
* `apt install curl wget -y`
* `apt install ncurses-utils -y`
* `apt install ruby -y`
* `gem install lolcat`
* `git clone https://github.com/wilian-lgn/insecam`
* `cd insecam`
* `bash insecam.sh`
